exec  > >(tee stdout.txt)
exec 2> >(tee stderr.txt)
